<?php

// Započni novu ili nastavi postojeću sesiju
session_start();

// Uključi vanjsku biblioteku
include 'baza.php';

// Inicijaliziraj bazu
$baza = new Baza();

$artikli = $baza->query('SELECT * FROM artikli');

?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Moja web stranica</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">

            <h1>Popis artikala</h1>

            <?php foreach($artikli as $artikal): ?>

                <h3><?php echo $artikal['ime']; ?></h3>
                <p><strong>Opis:</strong> <?php echo $artikal['opis']; ?></p>
                <p><strong>Cijena:</strong> <?php echo $artikal['cijena']; ?>KM</p>
                <a href="datoteke/<?php echo $artikal['slika']; ?>">Preuzmi sliku</a>
                <hr>

            <?php endforeach; ?>

        </div>
    </div>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>
